function allerA(destination) {
    window.location.href = destination + '.html';
}

document.addEventListener('DOMContentLoaded', function() {
    var existingBackground = document.querySelector('.background');
    var backgroundImage = window.getComputedStyle(existingBackground).getPropertyValue('background-image');
    var style = document.createElement('style');
    style.innerHTML = `
        body::before {
            content: '';
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-image: ${backgroundImage};
            filter: blur(5px);
            z-index: -1;
            background-repeat: no-repeat;
            background-size: cover;
            background-attachment: fixed;
        }
    `;
    document.head.appendChild(style);
});

function randomizeDestinationForPage() {
 var randomNum = Math.floor(Math.random() * 2) + 1;
 var destination = randomNum === 1 ? 'Chemin2Part4' : 'Chemin2Part5';
 window.location.href = destination + '.html';
}

document.addEventListener('DOMContentLoaded', function() {
    const audioElement = document.querySelector('.myAudio');
    audioElement.volume = 0.2; 
    document.addEventListener('click', function() {
        audioElement.play();
    });
});